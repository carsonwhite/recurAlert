/** @type {import('tailwindcss').Config} */
export default {
	plugins: [],
	theme: {
		extend: {},
	},
	content: ["./index.html", './src/**/*.{html,svelte,js,ts}'],
	variants: {
		extend: {},
	},
}

