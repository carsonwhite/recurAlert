Build with `npm run build`

Built with node: v20.17.0

Icon source: https://www.shareicon.net/curved-arrow-exclamation-mark-curve-arrow-exclamations-curve-arrows-arrows-reload-704820